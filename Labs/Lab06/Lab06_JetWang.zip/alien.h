
//{{BLOCK(alien)

//======================================================================
//
//	alien, 40x32@8, 
//	+ palette 256 entries, not compressed
//	+ bitmap not compressed
//	Total size: 512 + 1280 = 1792
//
//	Time-stamp: 2020-02-27, 16:18:05
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_ALIEN_H
#define GRIT_ALIEN_H

#define alienBitmapLen 1280
extern const unsigned short alienBitmap[640];

#define alienPalLen 512
extern const unsigned short alienPal[256];

#endif // GRIT_ALIEN_H

//}}BLOCK(alien)
