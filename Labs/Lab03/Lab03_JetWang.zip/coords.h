#define NUMCOORDS 190
extern int visiblePersonRows[NUMCOORDS];
extern int visiblePersonCols[NUMCOORDS];
extern int invisiblePersonRows[NUMCOORDS];
extern int invisiblePersonCols[NUMCOORDS];
